package com.example.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Category;
import com.example.Entity.Product;
import com.example.Service.MyService;

@RestController
public class MyController {
	@Autowired
	MyService service;
	@PostMapping("/savedata")
	public String saveproduct(@RequestBody Product pro)
	{
		return service.savedata(pro);
	}
	@GetMapping("/findid/{id}")
	public Product findbyid(@PathVariable("id") int id) 
	{
		return service.findbyid(id);
	
	}
	@GetMapping("/deleteid/{id}")
	public String deletebyid(@PathVariable("id") int id)
	{
		return service.deletebyid(id);
	
	}
	@PutMapping("/updatelib/{id}")
	public String update(@PathVariable("id") int id, @RequestBody Product pro)
	{
		return service.update(id, pro);
				
	}
	
	@PostMapping("/save")
	public String savecategory(@RequestBody Category c)
	{
		return service.save(c);
	
	}
	@GetMapping("/idfind/{id}")
	public Product findid(@PathVariable("id") int id) 
	{
		return service.findbyid(id);
	
	}
	@GetMapping("/iddelete/{id}")
	public String deleteid(@PathVariable("id") int id)
	{
		return service.deletebyid(id);
	
	}
	@PutMapping("/update/{id}")
	public String updated(@PathVariable("id") int id, @RequestBody Category cat)
	{
		return service.update(id, cat);
							
	}
	@PostMapping("/onetomany")
	public String save (@RequestBody Category c)
	{
       return service.onetomany(c);
							
	}
	
	

}
