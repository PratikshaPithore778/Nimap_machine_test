package com.example.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.Category;
import com.example.Entity.Product;
import com.example.Repository.CategoryRepository;
import com.example.Repository.ProductRepository;

@Service
public class MyService {
	
	@Autowired
	ProductRepository pro;

	public String savedata(Product p)
	{
		pro.save(p);

		return "record added successfully";
	}
	public Product findbyid(int id)
	{
		return pro.findById(id) .orElse(null);
	}
	public String deletebyid(int id)
	{
		pro.deleteById(id);
		return "record deleted successfully";
	}
	public String update(int id,Product p)
	{
		Product pr=pro.findById(id).orElse(null);
		if(p!=null)
		{
			if(p.getName()!=null)
			{
				pr.setName(p.getName());
			}
			if(p.getPrice()!=0.0)
			{
				pr.setPrice(p.getPrice());
			}
		}
		pro.save(pr);
		return "product updated successfully";
	}
	
	
	@Autowired
	CategoryRepository cat;
	
	public String save(Category c)
	{
		cat.save(c);

		return "record added successfully";
	}
	public Category findid(int id)
	{
		return cat.findById(id) .orElse(null);
	}
	public String deleteid(int id)
	{
		pro.deleteById(id);
		return "record deleted successfully";
	}
	public String update(int cid,Category c)
	{
	    Category ct=cat.findById(cid).orElse(null);
		if(c!=null)
		{
			if(c.getCname()!=null)
			{
				ct.setCname(c.getCname());
			}
			
		}
	     cat.save(ct);
		return "product updated successfully";
	}
	
	public String onetomany(Category ca)
	{
		for(Product p:ca.getPt())
		{
		 p.setCt(ca);
		}
	cat.save(ca);
		return "record added successfully";
	}
}
